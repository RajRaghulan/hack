from django.shortcuts import render
import pandas as pd
import plotly.express as px

def home(request):
    context = {'show_graph': False, 'show_globe': False}  # Initialize context with flags
    if request.method == 'POST' and request.FILES.get('csv_file'):
        csv_file = request.FILES['csv_file']
        if not csv_file.name.endswith('.csv'):
            context['error'] = 'Please upload a CSV file.'
            return render(request, 'myapp/home.html', context)

        try:
            df = pd.read_csv(csv_file)
            # Assuming the CSV file has columns 'Category' and 'Value'
            # Change the graph to a horizontal bar chart and specify a larger size
            fig = px.bar(df, y='Category', x='Value',
                         title='Data from CSV File',
                         orientation='h',
                         height=600, width=600)  # Adjust height and width as needed
            context['graph_data'] = fig.to_html(full_html=False)
            context['show_graph'] = True
            context['show_globe'] = True  # Show the globe ipecifics
        except Exception as e:
            context['error'] = f'Error reading CSV file: {str(e)}'

    return render(request, 'myapp/home.html', context)
